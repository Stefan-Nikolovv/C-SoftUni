﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=(LocalDb)\MSSQLLocalDB;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
