﻿namespace Boardgames
{
    using AutoMapper;

    public class BoardgamesProfile : Profile
    {
        // DO NOT CHANGE OR RENAME THIS CLASS!
        public BoardgamesProfile()
        {
            
        }
    }
}