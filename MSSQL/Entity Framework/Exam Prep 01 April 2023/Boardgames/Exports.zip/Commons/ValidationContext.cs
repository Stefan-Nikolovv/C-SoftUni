﻿

namespace Boardgames.Commons
{
    public static class ValidationConstants

    {
        //Seller
        public const string SelerWebSiteRegex = @"^www.[a-zA-Z0-9-]+.com";
    }
}
