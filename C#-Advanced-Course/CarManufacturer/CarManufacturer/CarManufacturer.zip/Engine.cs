﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarManufacturer
{
    public class Engine
    {

        public Engine(int hoursePower, double cubicCapacity)
        {
            this.HoursePower = hoursePower;
			this.CubicCapacity = cubicCapacity;
        }
        private int hoursePower;

		public int HoursePower
		{
			get { return this.hoursePower; }
			set { this.hoursePower = value; }
		}
		private double cubicCapacity;

		public double CubicCapacity
		{
			get { return this.cubicCapacity; }
			set { this.cubicCapacity = value; }
		}


	}
}
