﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
           Engine engine =  new Engine(170,2);
            Tire[] tires = new Tire[4]
            {
                new Tire(2022, 2.2),
                new Tire(2022, 2.2),
                new Tire(2022, 2.2),
                new Tire(2022, 2.2)
            };
            
            Car car = new Car("Mercedes-Benz", "e220", 2007, 65, 6.5, engine, tires );

        }
    }
}