﻿

namespace DefiningClasses;


public class StartUp
{
    public static void Main(string[] args)
    {
       string startDate = Console.ReadLine();
        string endDate = Console.ReadLine();
        int diffDays = DateModifier.Modified(startDate, endDate);

        Console.WriteLine(diffDays);

    }
}
