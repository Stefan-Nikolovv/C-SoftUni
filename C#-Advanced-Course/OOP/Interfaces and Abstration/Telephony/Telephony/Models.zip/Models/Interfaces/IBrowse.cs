﻿public interface IBrowse
{
    string Browse(string url);
}