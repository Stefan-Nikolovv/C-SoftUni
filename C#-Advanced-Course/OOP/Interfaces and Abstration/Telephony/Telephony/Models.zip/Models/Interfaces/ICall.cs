﻿public interface ICall
{
    string Call(string phoneNuber);
}