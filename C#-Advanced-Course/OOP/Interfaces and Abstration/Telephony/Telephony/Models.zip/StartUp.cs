﻿

using Telephony.Models;

try
{
    string[] phoneNumbers = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

    string[] urls = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

    ICall phone;
    
    foreach (string phoneNumber in phoneNumbers)
    {
        if (phoneNumber.Length == 10)
        {
            phone = new Smartphone();
        }
        else
        {
            phone = new StationaryPhone();

        }
        Console.WriteLine(phone.Call(phoneNumber)); 
    }
    IBrowse browse = new Smartphone();
    foreach (string url in urls)
    {
        Console.WriteLine(browse.Browse(url));

    }

}
catch (Exception ex)
{

    Console.WriteLine(ex.Message);
}