﻿using MilitaryElite.Core;
using MilitaryElite.Core.Interfaces;
using MilitaryElite.Models.Interfaces;

IEngine engine = new Engine();
engine.Run();