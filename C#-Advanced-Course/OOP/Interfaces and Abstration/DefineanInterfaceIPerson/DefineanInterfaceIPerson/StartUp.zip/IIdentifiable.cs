﻿//Do not remove because of judge. Don't put in folders because of the namespace.
namespace PersonInfo;


    public interface IIdentifiable
    {
        string Id { get; }
    }
