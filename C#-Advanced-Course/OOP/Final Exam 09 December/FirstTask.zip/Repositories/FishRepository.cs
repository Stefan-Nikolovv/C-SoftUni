﻿
using NauticalCatchChallenge.Models.Contracts;
using NauticalCatchChallenge.Repositories.Contracts;

namespace NauticalCatchChallenge.Repositories
{
    public class FishRepository : IRepository<IFish>
    {
        private List<IFish> fish;
        public IReadOnlyCollection<IFish> Models => fish.AsReadOnly();

        public void AddModel(IFish model)
        {
            fish.Add(model);
        }

        public IFish GetModel(string name)
        {
            return fish.FirstOrDefault(x => x.Name == name);
        }
    }
}
